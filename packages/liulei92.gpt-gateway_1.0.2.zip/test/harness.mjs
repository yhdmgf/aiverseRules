/**
 * 冒烟测试（node test/harness.mjs）。
 *
 * 覆盖：JWT 格式与签名、消息翻译、TOOL_CALL 流式解析、JSON 修复、
 * 拒绝判定、模型映射、网关路由（/health、/v1/models、鉴权、错误入参）。
 * 不打真实上游——真实上游的流式/生图验证走真机（plan 第十节 1-4 步）。
 */

import { createRequire } from 'node:module';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const require = createRequire(import.meta.url);
process.env.AICODE_DATA_DIR = fs.mkdtempSync(path.join(os.tmpdir(), 'gpt-gateway-test-'));

const begamob = require('../lib/begamob');
const gateway = require('../lib/gateway');
const { UpstreamError, classify } = require('../lib/errors');

/** fetch 包装：stop 强关连接后，客户端连接池里会残留已关闭的旧 socket，
 * 第一次请求可能报 "other side closed"；重试一次模拟真实客户端（OkHttp 对网络错误自动重试）。 */
async function fetchWithRetry(url, init) {
  try {
    return await fetch(url, init);
  } catch (e) {
    return fetch(url, init);
  }
}

let passed = 0;
const failures = [];

async function test(name, fn) {
  try {
    await fn();
    passed++;
    console.log(`  ok  ${name}`);
  } catch (e) {
    failures.push({ name, e });
    console.error(`FAIL  ${name}\n      ${e.message}`);
  }
}

// ── 1. JWT ────────────────────────────────────────────────────

await test('JWT：三段结构、payload 字段、exp=iat+1800、HS256 签名可验', () => {
  const jwt = begamob.buildJwt();
  const parts = jwt.split('.');
  assert.equal(parts.length, 3);

  const payload = JSON.parse(Buffer.from(parts[1], 'base64').toString('utf8'));
  assert.equal(payload.bundleId, 'com.chat.chatai.chatbot.aichatbot');
  assert.equal(payload.os, 'Android');
  assert.equal(payload.versionApp, '1.5.7');
  assert.equal(payload.timezone, 'Asia/Shanghai');
  assert.equal(payload.exp - payload.iat, 1800);

  const expect = crypto
    .createHmac('sha256', 'stteam-ikameglobal-chatapiopenai')
    .update(`${parts[0]}.${parts[1]}`)
    .digest('base64')
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=+$/, '');
  assert.equal(parts[2], expect);
});

await test('JWT：签名密钥错误时校验失败（防呆）', () => {
  const jwt = begamob.buildJwt();
  const [h, p, s] = jwt.split('.');
  const bad = crypto.createHmac('sha256', 'wrong-key').update(`${h}.${p}`).digest('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  assert.notEqual(s, bad);
});

// ── 2. 消息翻译 ───────────────────────────────────────────────

await test('buildMessages：system 折叠进下一条 user，tools 注入协议提示词', () => {
  const tools = [
    {
      type: 'function',
      function: {
        name: 'get_weather',
        description: '查询城市天气',
        parameters: { type: 'object', properties: { city: { type: 'string' } } },
      },
    },
  ];
  const msgs = [
    { role: 'system', content: '你是助手' },
    { role: 'user', content: '北京天气怎么样' },
  ];
  const out = begamob.buildMessages(msgs, tools);

  assert.equal(out.length, 1);
  assert.equal(out[0].role, 'user');
  const sys = out[0].content[0].text;
  assert.ok(sys.includes('[系统]'), 'system 前缀');
  assert.ok(sys.includes('你是助手'), 'system 内容');
  assert.ok(sys.includes('TOOL_CALL: 工具名'), '协议格式说明');
  assert.ok(sys.includes('get_weather'), '工具清单');
  assert.ok(sys.includes('{"city": "string"}'), '参数 schema');
  assert.ok(sys.includes('北京天气怎么样'), 'user 正文拼接在 system 之后');
});

await test('buildMessages：assistant tool_calls 还原为 TOOL_CALL 文本，tool 结果转 user', () => {
  const msgs = [
    { role: 'user', content: '查天气' },
    {
      role: 'assistant',
      content: '',
      tool_calls: [{ id: 'call_1', type: 'function', function: { name: 'get_weather', arguments: '{"city":"北京"}' } }],
    },
    { role: 'tool', tool_call_id: 'call_1', content: '晴 25°C' },
    { role: 'user', content: [{ type: 'text', text: '谢谢' }] },
  ];
  const out = begamob.buildMessages(msgs, []);

  assert.equal(out.length, 4);
  assert.equal(out[1].role, 'assistant');
  assert.ok(out[1].content[0].text.includes('TOOL_CALL: get_weather({"city":"北京"})'));
  assert.equal(out[2].role, 'user');
  assert.ok(out[2].content[0].text.includes('[工具结果] call_1 返回：'));
  assert.ok(out[2].content[0].text.includes('晴 25°C'));
  assert.equal(out[3].content[0].text, '谢谢');
});

await test('buildMessages：只有 system 时协议提示词独立成首条 user', () => {
  const out = begamob.buildMessages([{ role: 'system', content: '只有系统提示' }], []);
  assert.equal(out.length, 1);
  assert.equal(out[0].role, 'user');
  assert.ok(out[0].content[0].text.includes('只有系统提示'));
});

// ── 3. JSON 修复与 TOOL_CALL 解析 ─────────────────────────────

await test('repairJson：围栏剥离、单引号转双引号、空值兜底', () => {
  assert.equal(begamob.repairJson('{"a":1}'), '{"a":1}');
  assert.equal(begamob.repairJson("{'a':1}"), '{"a":1}');
  assert.equal(begamob.repairJson('```json\n{"a":1}\n```'), '{"a":1}');
  assert.equal(begamob.repairJson(''), '{}');
});

await test('parseToolCall：标准格式与非法文本', () => {
  assert.deepEqual(begamob.parseToolCall('TOOL_CALL: a({"x":1})'), { name: 'a', arguments: '{"x":1}' });
  assert.deepEqual(begamob.parseToolCall("TOOL_CALL: get({'k':'v'})"), { name: 'get', arguments: '{"k":"v"}' });
  assert.equal(begamob.parseToolCall('普通文本'), null);
});

await test('TOOL_CALL 翻译器：跨增量解析单个调用', () => {
  const tr = begamob.createToolCallTranslator();
  const r1 = tr.feed('今天天气');
  assert.equal(r1.content, '今天天气');
  assert.equal(r1.toolCalls.length, 0);

  const r2 = tr.feed('不错\nTOOL_CALL: get_we');
  assert.equal(r2.content, '不错\n');
  assert.equal(r2.toolCalls.length, 0);

  const r3 = tr.feed('ather({"city": "北');
  assert.equal(r3.content, '');
  assert.equal(r3.toolCalls.length, 0);

  const r4 = tr.feed('京"})');
  assert.equal(r4.content, '');
  assert.equal(r4.toolCalls.length, 1);
  assert.equal(r4.toolCalls[0].name, 'get_weather');
  assert.equal(r4.toolCalls[0].arguments, '{"city": "北京"}');
});

await test('TOOL_CALL 翻译器：一次增量包含两个调用（含单引号修复）', () => {
  const tr = begamob.createToolCallTranslator();
  const r = tr.feed("TOOL_CALL: a({\"x\":1}) 中间 TOOL_CALL: b({'y':2})");
  assert.equal(r.content, ' 中间 ');
  assert.equal(r.toolCalls.length, 2);
  assert.equal(r.toolCalls[0].name, 'a');
  assert.equal(r.toolCalls[1].name, 'b');
  assert.equal(r.toolCalls[1].arguments, '{"y":2}');
});

await test('TOOL_CALL 翻译器：残缺调用在流结束时按正文吐出', () => {
  const tr = begamob.createToolCallTranslator();
  tr.feed('TOOL_CALL: broken({"x":');
  const rest = tr.flush();
  assert.ok(rest.includes('TOOL_CALL: broken('), '残缺调用归还正文');
});

await test('TOOL_CALL 翻译器：字符串内的括号不参与配对', () => {
  const tr = begamob.createToolCallTranslator();
  const r = tr.feed('TOOL_CALL: say({"text": "带(括号)和}花括号"})');
  assert.equal(r.toolCalls.length, 1);
  assert.equal(r.toolCalls[0].name, 'say');
  assert.equal(r.toolCalls[0].arguments, '{"text": "带(括号)和}花括号"}');
});

// ── 4. 拒绝判定与模型映射 ─────────────────────────────────────

await test('isRefusal：开头强特征命中，正常正文不误判', () => {
  assert.equal(begamob.isRefusal('我不能提供这类内容'), true);
  assert.equal(begamob.isRefusal('作为人工智能我无法这样做'), true);
  assert.equal(begamob.isRefusal("I can't help with that"), true);
  assert.equal(begamob.isRefusal('Sorry, I cannot do that.'), true);
  assert.equal(begamob.isRefusal('今天天气不错，我们去公园走走吧。'), false);
  assert.equal(begamob.isRefusal('好的，我来帮你写一个冒泡排序：'), false);
});

await test('isRefusal：弱特征只对短文本生效', () => {
  assert.equal(begamob.isRefusal('由于伦理原因无法提供'), true);
  assert.equal(begamob.isRefusal('由于伦理原因无法提供'.padEnd(400, '啊')), false);
  assert.equal(begamob.isRefusal(''), false);
});

await test('mapModel：精确映射、剥前缀透传、空值兜底', () => {
  assert.equal(begamob.mapModel('gpt-5-mini'), 'gpt-5-mini');
  assert.equal(begamob.mapModel('gemini-2.5-pro'), 'gemini-2.5-pro');
  assert.equal(begamob.mapModel('onesearch-gpt-4o'), 'gpt-4o');
  assert.equal(begamob.mapModel(''), 'gpt-5-mini');
  assert.equal(begamob.mapModel(undefined), 'gpt-5-mini');
});

// ── 5. 错误分类 ───────────────────────────────────────────────

await test('classify：CF 拦截与限频文案归 rate_limit 并带 Retry-After', () => {
  const cf = classify(403, '<html>Just a moment...</html>');
  assert.equal(cf.kind, 'rate_limit');
  assert.equal(cf.status, 429);
  assert.ok(cf.retryAfterMs > 0);

  const rl = classify(429, 'too many requests');
  assert.equal(rl.kind, 'rate_limit');
  assert.ok(rl instanceof UpstreamError);
});

await test('classify：普通 5xx 归 upstream，不带 Retry-After', () => {
  const e = classify(500, 'internal error');
  assert.equal(e.kind, 'upstream');
  assert.equal(e.status, 502);
  assert.equal(e.retryAfterMs, 0);
});

// ── 6. 网关路由 ───────────────────────────────────────────────

const TEST_PORT = 18917;

await test('gateway：/health 与 /v1/models（三模型）', async () => {
  await gateway.start(TEST_PORT, [], '127.0.0.1');
  assert.ok(gateway.isRunning());

  let r = await fetch(`http://127.0.0.1:${TEST_PORT}/health`);
  assert.equal(r.status, 200);
  const health = await r.json();
  assert.equal(health.service, 'gpt-gateway');

  r = await fetch(`http://127.0.0.1:${TEST_PORT}/v1/models`);
  assert.equal(r.status, 200);
  const list = await r.json();
  assert.equal(list.object, 'list');
  assert.deepEqual(
    list.data.map((m) => m.id).sort(),
    ['gemini-2.5-pro', 'goatchat-image', 'gpt-4o', 'gpt-4o-mini', 'gpt-5', 'gpt-5-mini'],
  );
});

await test('gateway：错误入参 400、未知路由 404', async () => {
  let r = await fetch(`http://127.0.0.1:${TEST_PORT}/v1/chat/completions`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: 'not-json',
  });
  assert.equal(r.status, 400);

  r = await fetch(`http://127.0.0.1:${TEST_PORT}/v1/chat/completions`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ model: 'gpt-5-mini', messages: [] }),
  });
  assert.equal(r.status, 400);

  r = await fetch(`http://127.0.0.1:${TEST_PORT}/v1/nope`);
  assert.equal(r.status, 404);
});

await test('gateway：鉴权开关（Bearer 与 x-api-key，空=放行）', async () => {
  gateway.setApiKeys(['secret1']);
  let r = await fetch(`http://127.0.0.1:${TEST_PORT}/v1/models`);
  assert.equal(r.status, 401);

  r = await fetch(`http://127.0.0.1:${TEST_PORT}/v1/models`, { headers: { Authorization: 'Bearer secret1' } });
  assert.equal(r.status, 200);

  r = await fetch(`http://127.0.0.1:${TEST_PORT}/v1/models`, { headers: { 'x-api-key': 'secret1' } });
  assert.equal(r.status, 200);

  r = await fetch(`http://127.0.0.1:${TEST_PORT}/v1/models`, { headers: { Authorization: 'Bearer wrong' } });
  assert.equal(r.status, 401);

  gateway.setApiKeys([]);
  r = await fetch(`http://127.0.0.1:${TEST_PORT}/v1/models`);
  assert.equal(r.status, 200);
});

await test('gateway：图片代理仅允许 goatchat CDN 域名', async () => {
  let r = await fetch(`http://127.0.0.1:${TEST_PORT}/proxy/image?url=${encodeURIComponent('https://evil.com/x.jpeg')}`);
  assert.equal(r.status, 403);

  r = await fetch(`http://127.0.0.1:${TEST_PORT}/proxy/image`);
  assert.equal(r.status, 403);
});

await test('gateway：停止后端口释放', async () => {
  await gateway.stop();
  assert.equal(gateway.isRunning(), false);
});

// ── 7. 启动/停止竞态（1.0.1 修复） ───────────────────────────

await test('gateway：并发 start 去重，只产生一个监听', async () => {
  const [a, b] = await Promise.all([
    gateway.start(TEST_PORT, [], '127.0.0.1'),
    gateway.start(TEST_PORT, [], '127.0.0.1'),
  ]);
  assert.ok(a.port === TEST_PORT || a.already);
  assert.ok(b.port === TEST_PORT || b.already);
  // 只有一个监听：第二次请求能通
  const r = await fetchWithRetry(`http://127.0.0.1:${TEST_PORT}/health`);
  assert.equal(r.status, 200);
  assert.ok(gateway.isRunning());
});

await test('gateway：stop 后立即 start（模拟 save_config 重启）不撞 EADDRINUSE', async () => {
  const stopPromise = gateway.stop();
  const startPromise = gateway.start(TEST_PORT, [], '127.0.0.1');
  await Promise.all([stopPromise, startPromise]);
  assert.ok(gateway.isRunning());
  const r = await fetchWithRetry(`http://127.0.0.1:${TEST_PORT}/health`);
  assert.equal(r.status, 200);
});

await test('gateway：stop 强关存活连接，端口立即释放', async () => {
  // 建一个 keep-alive 连接
  const http = await import('node:http');
  const agent = new http.Agent({ keepAlive: true });
  await new Promise((resolve) => {
    const req = http.get({ host: '127.0.0.1', port: TEST_PORT, path: '/health', agent }, (res) => {
      res.resume();
      res.on('end', resolve);
    });
    req.on('error', resolve);
  });
  const t0 = Date.now();
  await gateway.stop();
  const elapsed = Date.now() - t0;
  assert.ok(elapsed < 1500, `stop 应快速完成，实际 ${elapsed}ms`);
  // 立即重启验证端口可用
  await gateway.start(TEST_PORT, [], '127.0.0.1');
  assert.ok(gateway.isRunning());
  await gateway.stop();
});

// ── 汇总 ──────────────────────────────────────────────────────

console.log(`\n${passed} passed, ${failures.length} failed`);
if (failures.length > 0) {
  process.exit(1);
}
