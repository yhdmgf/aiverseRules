// 模拟宿主，走完整的 NDJSON JSON-RPC 往返，验证两个工具与提示条格式。
// 运行：node test/harness.mjs
import { spawn } from 'node:child_process';
import { strict as assert } from 'node:assert';

const proc = spawn(process.execPath, ['dist/main.js'], { stdio: ['pipe', 'pipe', 'inherit'] });

let buffer = '';
const waiters = [];        // 等待特定入站消息的 promise
const hostCalls = [];      // 插件发起的 host.* 调用记录
let clipboardText = '';    // 模拟系统剪贴板
let notifyFails = false;   // 模拟通知发送失败（无通知权限）
let secretNotify = '';     // 模拟 secrets 里 notify.enabled 的值：'' 默认开启
const failIf = [];         // stdout 解析失败则记录

proc.stdout.on('data', (chunk) => {
  buffer += chunk.toString('utf8');
  let idx;
  while ((idx = buffer.indexOf('\n')) >= 0) {
    const line = buffer.slice(0, idx);
    buffer = buffer.slice(idx + 1);
    if (!line.trim()) continue;
    let msg;
    try {
      msg = JSON.parse(line);
    } catch {
      failIf.push(line);
      continue;
    }
    dispatch(msg);
  }
});

function dispatch(msg) {
  for (let i = 0; i < waiters.length; i++) {
    if (waiters[i].match(msg)) {
      const w = waiters.splice(i, 1)[0];
      w.resolve(msg);
      return;
    }
  }
  if (msg.method && msg.id !== undefined) {
    handleHostCall(msg);
    return;
  }
  throw new Error('unexpected message: ' + JSON.stringify(msg));
}

function handleHostCall(msg) {
  hostCalls.push(msg);
  let result;
  switch (msg.method) {
    case 'host.clipboard.write':
      clipboardText = String(msg.params.text);
      result = { ok: true };
      break;
    case 'host.clipboard.read':
      result = { text: clipboardText };
      break;
    case 'host.secrets.get':
      result = { value: secretNotify };
      break;
    case 'host.tip':
      result = { tipId: 'tip-test', queued: true };
      break;
    case 'host.notify':
      if (notifyFails) {
        send({ jsonrpc: '2.0', id: msg.id, error: { code: 'NOTIFICATION_PERMISSION_DENIED', message: 'no permission' } });
        return;
      }
      result = { ok: true };
      break;
    default:
      result = { ok: true };
  }
  send({ jsonrpc: '2.0', id: msg.id, result });
}

function send(obj) {
  proc.stdin.write(JSON.stringify(obj) + '\n');
}

function waitFor(match) {
  return new Promise((resolve) => waiters.push({ match, resolve }));
}

let rpcSeq = 0;
function invoke(handler, args) {
  const id = 'req-' + (++rpcSeq);
  const p = waitFor((m) => m.id === id);
  send({ jsonrpc: '2.0', id, method: 'tool.invoke', params: { handler, args } });
  return p;
}

function findTip(text) {
  return hostCalls
    .filter((m) => m.method === 'host.tip')
    .map((m) => String(m.params.text))
    .find((t) => t === text);
}

// ---------- 用例 ----------

// 1. copy 正常：长文本 → 提示条 <=30 字，带开始/结束片段
const longText = '你是小红书美妆文案专家，请根据以下产品信息写出三篇种草文案，每篇两百字，语气真诚不夸张，结尾带购买指引。';
clipboardText = '';
const r1 = await invoke('tools.copy', { text: longText });
assert.equal(r1.result.chars, longText.length);
assert.match(r1.result.message, /^已写入剪贴板（\d+ 字符）$/);
assert.equal(clipboardText, longText);
const tips1 = hostCalls.filter((m) => m.method === 'host.tip');
assert.equal(tips1.length, 1);
const tip1 = String(tips1[0].params.text);
assert.ok(tip1.length <= 30, 'tip 超 30 字: ' + tip1.length + ' -> ' + tip1);
assert.ok(tip1.startsWith('已复制' + longText.length + '字｜开始'), tip1);
assert.ok(tip1.includes('…结束…'), tip1);
// 通知兜底：内容与提示条一致
const notif1 = hostCalls.filter((m) => m.method === 'host.notify');
assert.equal(notif1.length, 1);
assert.equal(notif1[0].params.title, '剪贴板助手');
assert.equal(notif1[0].params.body, tip1);
assert.ok(notif1[0].params.body.length <= 30);

// 2. copy 超长文本 4096 字 → tip 仍 <=30
const huge = '一二三四五六七八九十'.repeat(409);
const r2 = await invoke('tools.copy', { text: huge });
const tip2 = String(hostCalls.filter((m) => m.method === 'host.tip').at(-1).params.text);
assert.ok(tip2.length <= 30, tip2);
assert.equal(r2.result.chars, huge.length);

// 3. copy 短文本 → 提示条「复制完成」
const r3 = await invoke('tools.copy', { text: 'hi' });
assert.equal(r3.result.chars, 2);
const tip3 = String(hostCalls.filter((m) => m.method === 'host.tip').at(-1).params.text);
assert.equal(tip3, '已复制2字｜复制完成');

// 4. copy 空文本 → 参数错误
const r4 = await invoke('tools.copy', { text: '   ' });
assert.equal(r4.error.code, 'PARAM_INVALID');

// 5. copy 超 1MB → TOO_LARGE（先判大小，不写剪贴板）
const before = hostCalls.length;
const r5 = await invoke('tools.copy', { text: 'x'.repeat(1024 * 1024 + 1) });
assert.equal(r5.error.code, 'TOO_LARGE');
assert.equal(hostCalls.length, before, 'TOO_LARGE 不应触发 host.clipboard.write');

// 6. read 非空
clipboardText = '粘过来的一段素材';
const r6 = await invoke('tools.read', {});
assert.equal(r6.result.text, '粘过来的一段素材');

// 7. read 空
clipboardText = '';
const r7 = await invoke('tools.read', {});
assert.equal(r7.result.text, '');
assert.equal(r7.result.empty, true);
assert.ok(r7.result.message.includes('不在前台'), r7.result.message);

// 8. 未知 handler
const r8 = await invoke('tools.nope', {});
assert.equal(r8.error.code, 'HANDLER_NOT_FOUND');

// 9. 未知 method
const id9 = 'req-method';
const w9 = waitFor((m) => m.id === id9);
send({ jsonrpc: '2.0', id: id9, method: 'bogus.invoke', params: {} });
const r9 = await w9;
assert.equal(r9.error.code, 'METHOD_UNKNOWN');

// 10. notify 失败（无通知权限）时复制仍成功
notifyFails = true;
clipboardText = '';
const r10 = await invoke('tools.copy', { text: '通知会失败但复制不受影响的一段内容' });
assert.equal(r10.result.chars, 17);
assert.equal(clipboardText, '通知会失败但复制不受影响的一段内容');
notifyFails = false;

// 11. 开关关闭（secrets notify.enabled='0'）时不弹提示条也不发通知
secretNotify = '0';
const before11 = hostCalls.length;
const r11 = await invoke('tools.copy', { text: '开关关闭时不发通知' });
assert.equal(r11.result.chars, 9);
assert.equal(clipboardText, '开关关闭时不发通知');
const frames11 = hostCalls.slice(before11);
assert.ok(!frames11.some((m) => m.method === 'host.notify'), '开关关闭后不应发通知');
assert.ok(!frames11.some((m) => m.method === 'host.tip'), '开关关闭后不应弹提示条');
secretNotify = '';

// 12. stdout 全部可解析
assert.deepEqual(failIf, []);

// 输出实际提示条样本供人工核对
const samples = hostCalls.filter((m) => m.method === 'host.tip').map((m) => m.params.text);
console.log('提示条样本：');
for (const s of samples) console.log('  「' + s + '」 (' + s.length + ' 字)');

proc.stdin.end();
console.log('\n全部用例通过 ✓');
