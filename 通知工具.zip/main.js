var $ptools = $ptools || [];

$ptools.push({
  name: 'send',
  description: '发送一条通知（Toast 提示）。',
  parameters: {
    type: 'object',
    properties: {
      title: { type: 'string', description: '通知标题' },
      body: { type: 'string', description: '通知内容' }
    },
    required: ['title', 'body']
  },
  handler: function (args) {
    ctx.notify(args.title || '', args.body || '');
    return { status: 'success', data: '已发送' };
  }
});
