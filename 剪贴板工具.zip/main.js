var $ptools = $ptools || [];

$ptools.push({
  name: 'get',
  description: '读取系统剪贴板文本内容。',
  parameters: { type: 'object', properties: {} },
  handler: function (args) {
    var t = ctx.clipboardGet();
    if (!t) return { status: 'error', message: '剪贴板为空或非文本' };
    return { status: 'success', data: t };
  }
});
