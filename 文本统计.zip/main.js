var $ptools = $ptools || [];

$ptools.push({
  name: 'stats',
  description: '统计文本的字符数、单词数、行数。',
  parameters: {
    type: 'object',
    properties: { text: { type: 'string', description: '要统计的文本' } },
    required: ['text']
  },
  handler: function (args) {
    var t = args.text || '';
    var words = (t.trim().match(/\S+/g) || []).length;
    var lines = t ? t.split('\n').length : 0;
    return { status: 'success', data: { chars: t.length, words: words, lines: lines } };
  }
});
