var $ptools = $ptools || [];

$ptools.push({
  name: 'ts2date',
  description: 'Unix 秒级时间戳转本地日期时间。',
  parameters: {
    type: 'object',
    properties: { ts: { type: 'string', description: '秒级时间戳' } },
    required: ['ts']
  },
  handler: function (args) {
    var d = new Date(Number(args.ts) * 1000);
    if (isNaN(d.getTime())) return { status: 'error', message: '无效时间戳' };
    return { status: 'success', data: d.toLocaleString() };
  }
});

$ptools.push({
  name: 'date2ts',
  description: '本地日期时间转 Unix 秒级时间戳（格式 yyyy-MM-dd HH:mm:ss）。',
  parameters: {
    type: 'object',
    properties: { text: { type: 'string', description: '日期时间，如 2026-11-08 10:00:00' } },
    required: ['text']
  },
  handler: function (args) {
    var t = new Date(args.text.replace(' ', 'T'));
    if (isNaN(t.getTime())) return { status: 'error', message: '无效日期' };
    return { status: 'success', data: Math.floor(t.getTime() / 1000) };
  }
});
