var $ptools = $ptools || [];

$ptools.push({
  name: 'read',
  description: '读取指定路径的文本文件内容（需要所有文件访问权限）。',
  parameters: {
    type: 'object',
    properties: {
      path: { type: 'string', description: '要读取的文件路径，如 /sdcard/xxx.txt' }
    },
    required: ['path']
  },
  handler: function (args) {
    var r = ctx.readSystemFile(args.path || '');
    try {
      return JSON.parse(r);
    } catch (e) {
      return { status: 'error', message: r };
    }
  }
});
