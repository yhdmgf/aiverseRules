var $ptools = $ptools || [];

$ptools.push({
  name: 'read',
  description: '读取指定路径的文本文件内容（需要所有文件访问权限）。',
  parameters: {
    type: 'object',
    properties: {
      path: { type: 'string', description: '要读取的文件路径，如 /sdcard/xxx.txt' }
    },
    required: ['path']
  },
  handler: function (args) {
    var r = ctx.readSystemFile(args.path || '');
    try {
      return JSON.parse(r);
    } catch (e) {
      return { status: 'error', message: r };
    }
  }
});

$ptools.push({
  name: 'save',
  description: '把文本内容保存到指定路径（需要所有文件访问权限）。',
  parameters: {
    type: 'object',
    properties: {
      path: { type: 'string', description: '保存路径，如 /sdcard/Download/xxx.txt' },
      content: { type: 'string', description: '要保存的内容' }
    },
    required: ['path', 'content']
  },
  handler: function (args) {
    var r = ctx.writeSystemFile(args.path || '', args.content || '');
    try {
      return JSON.parse(r);
    } catch (e) {
      return { status: 'error', message: r };
    }
  }
});
